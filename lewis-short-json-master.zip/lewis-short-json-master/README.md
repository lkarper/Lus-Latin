# JSON Lewis & Short
A Latin dictionary in JSON format, based off of the Perseus Project's Lewis and Short XML version.

## Credits

Text provided by Perseus Digital Library, with funding from The National Endowment for the Humanities. 

Original version available for viewing and download at http://www.perseus.tufts.edu/